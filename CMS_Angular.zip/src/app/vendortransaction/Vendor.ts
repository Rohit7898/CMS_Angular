interface Ventrans {
    id: number,
    employeename:string,
    empid:number, 
    itemname: string,
    price: number
}