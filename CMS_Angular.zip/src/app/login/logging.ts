export class Details {
    constructor(
      public username: string,
      public password: string,
      public role: string,
    ) {  }
  }