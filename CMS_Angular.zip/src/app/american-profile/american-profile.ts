interface americanprofile{
    name: string,
    address:string,
    emailid: number,
    contact: number,
    balance: number
}
