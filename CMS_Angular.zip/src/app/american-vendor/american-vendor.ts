interface AmericanVendor{
    id: number,
    name: string,
    price: number,
    image: any
}
