interface employee{
    image:any
    name: string,
    title:string,
    id: number,
    contact: number,
    balance: number
}
