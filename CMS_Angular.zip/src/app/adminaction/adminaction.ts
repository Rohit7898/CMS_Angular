interface adminact{
    id: number,
    vendorname: string,
    address:string,

    emailid: number,

    contact: number,

    balance: number
    
}
