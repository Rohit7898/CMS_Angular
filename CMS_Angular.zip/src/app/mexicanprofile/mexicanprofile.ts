interface mexicanprofile{
    name: string,
    address:string,
    emailid: number,
    contact: number,
    balance: number
}
