interface Emptrans {
    id: number,
     Vendor: string,
    
    itemname: string,
    price: number
}