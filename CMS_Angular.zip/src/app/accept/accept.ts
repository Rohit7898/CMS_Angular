interface AcceptOrder{
    
    id: number,
    name: string,
    amount: string,
    items: string
    
}